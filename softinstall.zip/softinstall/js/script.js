$(document).ready(function(){
  $(".menuToggler").click(function () {
    $("body").toggleClass("active");
  });
});